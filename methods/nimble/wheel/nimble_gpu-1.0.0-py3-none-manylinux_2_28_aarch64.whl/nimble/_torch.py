"""PyTorch entry points: nimble.init / alltoallv / all_to_all_single.
torch is imported lazily so the pure helpers of the package import
without it."""

from __future__ import annotations

import math
import os
import socket
from typing import Any, Sequence

import numpy as np

from . import _bootstrap
from ._comm import Communicator

_default: Communicator | None = None


def default_communicator() -> Communicator:
    if _default is None or not _default.alive:
        raise RuntimeError("nimble.init() has not been called (or the communicator was destroyed)")
    return _default


def _torch():
    import torch  # noqa: F401  (lazy: the helpers below run without torch)
    return torch


def _device_index(device: Any, torch) -> int:
    if device is None:
        return torch.cuda.current_device()
    if isinstance(device, int):
        return device
    dev = torch.device(device)
    if dev.type != "cuda":
        raise ValueError(f"NIMBLE needs a CUDA device, got {dev}")
    return dev.index if dev.index is not None else torch.cuda.current_device()


def init(*, device: Any = None, group: Any = None, bootstrap: str | None = None,
         timeout_ms: int = 0, library: str | None = None, rank: int | None = None,
         world_size: int | None = None, local_rank: int | None = None,
         local_world_size: int | None = None, set_default: bool = True) -> Communicator:
    """Create the NIMBLE communicator (collective across all ranks).

    Under an initialized torch.distributed process group (`group`, default
    the world): rank and world size come from the group, node grouping
    from an all-gather of hostnames, and the bootstrap endpoint from rank
    0, which binds a free TCP port on its host and broadcasts
    tcp://host:port. Otherwise the torchrun environment is used (RANK,
    WORLD_SIZE, LOCAL_RANK, LOCAL_WORLD_SIZE, MASTER_ADDR and
    NIMBLE_BOOTSTRAP or NIMBLE_BOOTSTRAP_PORT, default MASTER_PORT + 1).
    Explicit keyword values override both. The CUDA device (`device`,
    default LOCAL_RANK under torchrun, else the current device) is
    selected before the library initializes, as nimble.h requires.
    """
    global _default
    torch = _torch()
    dist = torch.distributed
    use_group = (rank is None and dist.is_available() and dist.is_initialized())

    if device is None:
        env_local = os.environ.get("LOCAL_RANK")
        device = int(env_local) if env_local not in (None, "") else None
    device = _device_index(device, torch)
    torch.cuda.set_device(device)

    if use_group:
        rank = dist.get_rank(group)
        world_size = dist.get_world_size(group)
        hosts: list = [None] * world_size
        dist.all_gather_object(hosts, socket.gethostname(), group=group)
        if local_rank is None or local_world_size is None:
            local_rank, local_world_size = _bootstrap.node_topology(hosts, rank)
        if bootstrap is None:
            item = [_bootstrap.bootstrap_endpoint(hosts[0], _bootstrap.free_tcp_port())] if rank == 0 else [None]
            dist.broadcast_object_list(item, src=dist.get_global_rank(group, 0) if group is not None else 0,
                                       group=group)
            bootstrap = item[0]
    else:
        resolved = {}
        if None in (rank, world_size, local_rank, local_world_size, bootstrap):
            resolved = _bootstrap.resolve_from_env()
        rank = resolved["rank"] if rank is None else rank
        world_size = resolved["world_size"] if world_size is None else world_size
        local_rank = resolved["local_rank"] if local_rank is None else local_rank
        local_world_size = resolved["local_world_size"] if local_world_size is None else local_world_size
        bootstrap = resolved["bootstrap"] if bootstrap is None else bootstrap

    comm = Communicator(rank=rank, world_size=world_size, local_rank=local_rank,
                        local_world_size=local_world_size, device=device, bootstrap=bootstrap,
                        timeout_ms=timeout_ms, library=library)
    comm.group = group
    if set_default:
        _default = comm
    return comm


def destroy() -> None:
    """Destroy the default communicator (collective)."""
    global _default
    if _default is not None:
        comm, _default = _default, None
        comm.destroy()


# -- host-side matrix helpers (pure; tested without a GPU) -----------------------

def rows_matrix(matrix: Any, world_size: int) -> np.ndarray:
    """The nranks-by-nranks table of dim-0 rows (source rank by row,
    destination by column) as int64. Accepts a tensor (CPU or CUDA; a CUDA
    tensor is copied to the host, which synchronizes), a numpy array or a
    nested sequence."""
    if hasattr(matrix, "detach"):          # torch tensor
        matrix = matrix.detach()
        if matrix.is_cuda:
            matrix = matrix.cpu()
        matrix = matrix.numpy()
    rows = np.asarray(matrix)
    if rows.shape != (world_size, world_size):
        raise ValueError(f"matrix shape {rows.shape} is not ({world_size}, {world_size})")
    if not np.issubdtype(rows.dtype, np.integer):
        raise ValueError(f"matrix must hold integer row counts, got dtype {rows.dtype}")
    rows = rows.astype(np.int64, copy=False)
    if (rows < 0).any():
        raise ValueError("matrix holds a negative count")
    return rows


def row_from_splits(split_sizes: Sequence[int] | None, dim0: int, world_size: int,
                    name: str) -> np.ndarray:
    """A rank's own row (or column) from a split list; equal split when the
    list is None, as torch.distributed.all_to_all_single defines it."""
    if split_sizes is None:
        if dim0 % world_size != 0:
            raise ValueError(f"{name}: dim 0 ({dim0}) is not divisible by the world size "
                             f"({world_size}) and no split sizes were given")
        return np.full(world_size, dim0 // world_size, dtype=np.int64)
    if hasattr(split_sizes, "tolist"):
        split_sizes = split_sizes.tolist()
    row = np.asarray(list(split_sizes), dtype=np.int64)
    if row.shape != (world_size,):
        raise ValueError(f"{name}: {row.shape[0] if row.ndim == 1 else row.shape} entries for "
                         f"{world_size} ranks")
    if (row < 0).any():
        raise ValueError(f"{name}: negative split size")
    if int(row.sum()) != dim0:
        raise ValueError(f"{name}: split sizes sum to {int(row.sum())}, dim 0 is {dim0}")
    return row


def validate_matrix(rows: np.ndarray, rank: int, input_dim0: int, output_dim0: int,
                    input_split_sizes: Sequence[int] | None,
                    output_split_sizes: Sequence[int] | None) -> None:
    """The caller's row must be its input, its column its output, and the
    split lists (when given) must agree with the matrix: a mismatch means
    the ranks would disagree on the collective, which the library does not
    re-verify on the hot path (nimble.h)."""
    world_size = rows.shape[0]
    row, column = rows[rank], rows[:, rank]
    if int(row.sum()) != input_dim0:
        raise ValueError(f"matrix row {rank} sums to {int(row.sum())} rows, input has {input_dim0}")
    if int(column.sum()) != output_dim0:
        raise ValueError(f"matrix column {rank} sums to {int(column.sum())} rows, output has {output_dim0}")
    if input_split_sizes is not None:
        given = row_from_splits(input_split_sizes, input_dim0, world_size, "input_split_sizes")
        if not np.array_equal(given, row):
            raise ValueError(f"input_split_sizes {given.tolist()} disagree with matrix row {row.tolist()}")
    if output_split_sizes is not None:
        given = row_from_splits(output_split_sizes, output_dim0, world_size, "output_split_sizes")
        if not np.array_equal(given, column):
            raise ValueError(f"output_split_sizes {given.tolist()} disagree with matrix column "
                             f"{column.tolist()}")


def row_bytes(shape: Sequence[int], element_size: int) -> int:
    """Bytes of one dim-0 row of a contiguous tensor."""
    return int(math.prod(shape[1:])) * int(element_size)


def check_tensor(tensor: Any, name: str, device: int, dtype: Any = None) -> None:
    if not hasattr(tensor, "is_cuda") or not tensor.is_cuda:
        raise ValueError(f"{name} must be a CUDA tensor")
    if tensor.device.index != device:
        raise ValueError(f"{name} is on cuda:{tensor.device.index}, the communicator on cuda:{device}")
    if not tensor.is_contiguous():
        raise ValueError(f"{name} must be contiguous")
    if tensor.dim() < 1:
        raise ValueError(f"{name} must have at least one dimension (split along dim 0)")
    if dtype is not None and tensor.dtype != dtype:
        raise ValueError(f"{name} dtype {tensor.dtype} differs from input dtype {dtype}")


# -- the collective ------------------------------------------------------------

def _resolve_stream(stream: Any, device: int, torch):
    """(handle, torch stream or None). None = the current stream; a
    torch.cuda.Stream (ExternalStream included); or a raw cudaStream_t."""
    if stream is None:
        current = torch.cuda.current_stream(device)
        return current.cuda_stream, current
    if isinstance(stream, torch.cuda.Stream):
        return stream.cuda_stream, stream
    if isinstance(stream, int):
        return stream, None
    raise TypeError(f"stream must be None, a torch.cuda.Stream or an integer handle, got {type(stream)}")


def _exchange_rows(comm: Communicator, row: np.ndarray, device: int, stream_handle: int,
                   torch) -> np.ndarray:
    """Every rank's row through one NIMBLE collective: each rank sends its
    row (8 * nranks bytes) to every rank; the receive buffer, packed by
    source, is the full matrix. This is the allgather nimble.h asks the
    application to perform; an application that already holds the table
    (Megatron, vLLM) passes `matrix=` and skips it."""
    n = comm.world_size
    send = torch.as_tensor(row, dtype=torch.int64).repeat(n).to(device, non_blocking=False)
    recv = torch.empty(n * n, dtype=torch.int64, device=device)
    comm.alltoallv_bytes(send.data_ptr(), recv.data_ptr(),
                         np.full((n, n), 8 * n, dtype=np.uint64), stream_handle)
    return recv.view(n, n).cpu().numpy()   # synchronizes the stream: the rows are needed on the host


def alltoallv(output: Any, input: Any, output_split_sizes: Sequence[int] | None = None,
              input_split_sizes: Sequence[int] | None = None, *, matrix: Any = None,
              comm: Communicator | None = None, stream: Any = None) -> None:
    """AllToAllV on `stream`, the torch.distributed.all_to_all_single shape.

    `input` is packed by destination rank and `output` by source rank
    along dim 0 (contiguous CUDA tensors, one dtype, equal trailing
    dimensions). `matrix` is the nranks-by-nranks table of dim-0 rows every
    rank holds after its count exchange (source by row); when omitted the
    rows are exchanged with one extra NIMBLE collective first. The call
    returns once the collective is enqueued; synchronize the stream to
    observe the output. A communicator is bound to the stream of its first
    collective (C API contract); a later call on another stream raises
    ValueError -- create one communicator per stream. Errors in the
    arguments raise ValueError before anything is enqueued; library
    failures raise NimbleError.
    """
    torch = _torch()
    comm = comm if comm is not None else default_communicator()
    check_tensor(input, "input", comm.device)
    check_tensor(output, "output", comm.device, input.dtype)
    if tuple(input.shape[1:]) != tuple(output.shape[1:]):
        raise ValueError(f"trailing dimensions differ: input {tuple(input.shape)}, "
                         f"output {tuple(output.shape)}")
    stream_handle, stream_obj = _resolve_stream(stream, comm.device, torch)
    n = comm.world_size
    if matrix is None:
        row = row_from_splits(input_split_sizes, input.size(0), n, "input_split_sizes")
        if stream_obj is not None:
            with torch.cuda.stream(stream_obj):
                rows = _exchange_rows(comm, row, comm.device, stream_handle, torch)
        else:
            rows = _exchange_rows(comm, row, comm.device, stream_handle, torch)
    else:
        rows = rows_matrix(matrix, n)
    validate_matrix(rows, comm.rank, input.size(0), output.size(0), input_split_sizes,
                    output_split_sizes)
    byte_matrix = rows.astype(np.uint64) * np.uint64(row_bytes(input.shape, input.element_size()))
    if stream_obj is not None and stream_obj != torch.cuda.current_stream(comm.device):
        input.record_stream(stream_obj)
        output.record_stream(stream_obj)
    comm.alltoallv_bytes(input.data_ptr() if input.numel() else 0,
                         output.data_ptr() if output.numel() else 0, byte_matrix, stream_handle)


def all_to_all_single(output: Any, input: Any, output_split_sizes: Sequence[int] | None = None,
                      input_split_sizes: Sequence[int] | None = None, group: Any = None,
                      async_op: bool = False, *, matrix: Any = None,
                      comm: Communicator | None = None, stream: Any = None) -> None:
    """torch.distributed.all_to_all_single with NIMBLE underneath: the same
    positional signature, so an application swaps one name. `group` must be
    None or the group the communicator was created from; `async_op` is not
    offered (the call is stream-ordered; synchronize the stream)."""
    if async_op:
        raise NotImplementedError("nimble.all_to_all_single is stream-ordered; async_op is not offered")
    comm = comm if comm is not None else default_communicator()
    if group is not None and comm.group is not None and group is not comm.group:
        raise ValueError("group differs from the group the NIMBLE communicator was created from")
    alltoallv(output, input, output_split_sizes, input_split_sizes, matrix=matrix, comm=comm,
              stream=stream)
