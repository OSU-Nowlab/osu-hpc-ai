"""The dedup core: MoE dispatch and combine as ONE NIMBLE collective per direction (NIMBLE_MATRIX_FLAG_DEDUP).

The row rule, decided per token and node on the device: a token bound for two or more ranks of a remote node, or
for that node's relay alone (the rank with the source's local index there), is STAGED for the node -- one row,
sent once to the relay, which fans it out over NVLink; every other (token, rank) pair is DIRECT, one row on the
normal path. The send buffer is the direct blocks in rank order, each its tokens in token order, then the pool (one
row per token). Rows carry the ABSOLUTE expert ids and every weight; the receiver converts them to its local
convention (local index, -1 elsewhere, weight 0 there). Region 0 of the receive buffer is the library's
rail-grouped block permutation of the fused layout, which the expert path does not depend on.

  plan      two launches, no host wait: per (token block, node) the membership, the row rule and block-relative
            positions; then the global positions, the row maps, the stage index and masks, and both chunk cuts,
            written in place into the vector the count exchange carries:
            [rank rows R | expert counts E | node rows N | dispatch cut N*C*G | combine cut N*Cr*G].
  pack      one launch over the direct rows and the pool.
  dispatch  the fan-out collective; one launch converts the received ids to local experts; the mask headers the
            reduce reads are copied into a compact buffer of 16-byte rows, so the fan-out's receive buffer is
            released with the expert rows instead of being held until the combine.
  combine   the reduce collective (each relay sums its node's rows in fp32 and rounds once to bf16), then one
            launch sums, per token, its direct rows and its node partials in fp32.
"""
from __future__ import annotations

from typing import NamedTuple, Optional

import numpy as np
import torch
import triton
import triton.language as tl

from .. import dedup as nd
from .core import RowLayout
from .fused import scale_words

CHUNK_BYTES = nd.CHUNK_BYTES
MASK_ROW_BYTES = 16         # the compact mask layout's row: the reduce reads only the mask headers


class DedupPlan(NamedTuple):
    direct_pos: torch.Tensor      # [T, R] int32: the token's position among the direct rows bound for d (-1 none)
    direct_counts: torch.Tensor   # [R] int64: direct rows per destination (the send buffer's blocks)
    direct_offsets: torch.Tensor  # [R] int64: the blocks' first send row
    node_pos: torch.Tensor        # [T, N] int32: the token's stage position for node m (-1 when not staged there)
    node_rows: torch.Tensor       # [N] int64: staged rows per node
    node_bits: torch.Tensor       # [T, N] int8: the token's local-rank bits on node m
    stage_index: torch.Tensor     # [T * N + 1] int32: the stage rows' SEND rows, node-major (used: sum(node_rows))
    stage_mask: torch.Tensor      # [T * N + 1] uint8: their local-rank masks
    row_tok: torch.Tensor         # [cap + 1] int32: the direct rows' tokens (send rows 0 .. direct total)
    row_dst: torch.Tensor         # [cap + 1] int32: their destinations
    slot_tgt: torch.Tensor        # [T, K] int32: the slot's rank when its row is direct (first slot per rank), else -1
    send_counts: torch.Tensor     # [R] int64: rows bound for each rank, direct + staged (the receive matrix's row)
    expert_counts: torch.Tensor   # [E] int64
    chunk_rows_d: torch.Tensor    # [N, C, G] int64: the dispatch's cut
    chunk_rows_r: torch.Tensor    # [N, Cr, G] int64: the combine's cut
    vec: torch.Tensor             # the count vector the exchange carries


@triton.jit
def _dedup_mask_snapshot(src_ptr, dst_ptr, geometry_ptr, PER_SRC, PER_DST,
                         R: tl.constexpr, BLOCK: tl.constexpr, CHUNK: tl.constexpr):
    """Program (s, b): the mask bytes of source s's stage-1 stream, keys b*BLOCK.., from the fan-out landing
    (PER_SRC rows per 8 MiB chunk) to the same keys of the compact layout (PER_DST rows per chunk); geometry =
    [source landing bases R | compact landing bases R | rows per source R]. No payload byte is read."""
    s, b = tl.program_id(0), tl.program_id(1)
    src_base = tl.load(geometry_ptr + s)
    dst_base = tl.load(geometry_ptr + R + s)
    count = tl.load(geometry_ptr + 2 * R + s)
    key = b * BLOCK + tl.arange(0, BLOCK)
    src = src_base + (key // PER_SRC).to(tl.int64) * CHUNK + key % PER_SRC
    dst = dst_base + (key // PER_DST).to(tl.int64) * CHUNK + key % PER_DST
    mask = tl.load(src_ptr + src, mask=key < count, other=0)
    tl.store(dst_ptr + dst, mask, mask=key < count)


@triton.jit
def _dedup_block_membership(ids_ptr, dpos_ptr, npos_ptr, nbits_ptr, counts_ptr, stgt_ptr, ecount_ptr,
                            T, R, NLOC, MYNODE, MYL, E,
                            G: tl.constexpr, N: tl.constexpr, K: tl.constexpr, KP: tl.constexpr, EP: tl.constexpr,
                            NB: tl.constexpr, BLOCK: tl.constexpr):
    """Program (b, m), token block b and node m: each token's local-rank bits on node m and the row rule (staged:
    m is not my node and the token names two or more of its ranks, or only my relay there); the block-relative
    positions -- npos[t, m] among the block's staged tokens, dpos[t, d] among its direct tokens for each rank d of m
    -- and the block's totals into counts [direct per rank R | members per rank R | staged per node N] x NB; each
    top-k slot's direct rank (its first occurrence, -1 when staged, masked or repeated) into stgt; on node 0's
    programs the expert histogram into ecount (int64 atomics)."""
    b, m = tl.program_id(0), tl.program_id(1)
    t = b * BLOCK + tl.arange(0, BLOCK)
    valid_t = t < T
    bits = tl.zeros([BLOCK], tl.int32)
    for k in tl.static_range(K):
        e = tl.load(ids_ptr + t.to(tl.int64) * K + k, mask=valid_t, other=-1)
        r = tl.maximum(e, 0) // NLOC
        hit = (e >= 0) & (r // G == m)
        bits |= tl.where(hit, 1 << (r % G), 0)
    multi = (bits & (bits - 1)) != 0
    staged = (multi | (bits == (1 << MYL))) & (bits != 0) & (m != MYNODE)
    s = staged.to(tl.int32)
    sp = tl.cumsum(s, 0) - 1
    tl.store(npos_ptr + t.to(tl.int64) * N + m, tl.where(staged, sp, -1), mask=valid_t)
    tl.store(nbits_ptr + t.to(tl.int64) * N + m, bits.to(tl.int8), mask=valid_t)
    tl.store(counts_ptr + (2 * R + m) * NB + b, tl.sum(s, 0))
    for g in tl.static_range(G):
        d = m * G + g
        member = ((bits >> g) & 1) != 0
        direct = member & ~staged
        dp = tl.cumsum(direct.to(tl.int32), 0) - 1
        tl.store(dpos_ptr + t.to(tl.int64) * R + d, tl.where(direct, dp, -1), mask=valid_t)
        tl.store(counts_ptr + d * NB + b, tl.sum(direct.to(tl.int32), 0))
        tl.store(counts_ptr + (R + d) * NB + b, tl.sum(member.to(tl.int32), 0))

    # a slot is direct exactly when its node's row is not staged; its first occurrence of a rank owns the row
    seen = tl.zeros([BLOCK], tl.int32)
    node0 = (tl.zeros([BLOCK], tl.int32) + m) == 0  # per lane: Triton 3.9's interpreter refuses a scalar-made mask
    for k in tl.static_range(K):
        e = tl.load(ids_ptr + t.to(tl.int64) * K + k, mask=valid_t, other=-1)
        r = tl.maximum(e, 0) // NLOC
        hit = (e >= 0) & (r // G == m)
        bit = 1 << (r % G)
        first = hit & ((seen & bit) == 0)
        target = tl.where(first & ~staged, r, -1)
        tl.store(stgt_ptr + t.to(tl.int64) * K + k, target,
                 mask=valid_t & (hit | ((e < 0) & node0)))
        seen |= tl.where(hit, bit, 0)
    if m == 0:
        kk = tl.arange(0, KP)
        experts = tl.load(ids_ptr + t[:, None].to(tl.int64) * K + kk[None, :],
                          mask=valid_t[:, None] & (kk[None, :] < K), other=-1)
        hist = tl.histogram(tl.reshape(tl.where(experts >= 0, experts, E), [BLOCK * KP]), EP)
        eo = tl.arange(0, EP)
        tl.atomic_add(ecount_ptr + eo, hist.to(tl.int64), mask=eo < E)


@triton.jit
def _dedup_block_maps(dpos_ptr, npos_ptr, nbits_ptr, prefix_ptr, dcount_ptr, nrows_ptr,
                      doff_ptr, noff_ptr, row_tok_ptr, row_dst_ptr, stage_index_ptr,
                      stage_mask_ptr, vec_ptr, T, R, PER_D, PER_R, VEC_NROWS, VEC_CUT_D, VEC_CUT_R,
                      G: tl.constexpr, N: tl.constexpr, C: tl.constexpr, CR: tl.constexpr,
                      NB: tl.constexpr, BP: tl.constexpr, RP: tl.constexpr, NP: tl.constexpr,
                      NBD: tl.constexpr, NBR: tl.constexpr, BLOCK: tl.constexpr):
    """Program (b, m): the global positions (the block-relative ones plus the earlier blocks' totals, summed here
    from the small count table: no extra launch, no cross-program dependency), the direct rows' token and
    destination at doff[d] + dpos, the stage index (SEND rows: the pool base + the token) and masks at
    noff[m] + npos, and both chunk cuts (dispatch PER_D, combine PER_R rows per chunk) by one histogram per local
    bit and one int64 atomic per bin into the count vector; block 0 also writes the per-rank and per-node totals
    and offsets."""
    b, m = tl.program_id(0), tl.program_id(1)
    t = b * BLOCK + tl.arange(0, BLOCK)
    tm = t < T
    rr = tl.arange(0, RP)
    bb = tl.arange(0, BP)
    dc_blocks = tl.load(prefix_ptr + rr[:, None] * NB + bb[None, :],
                        mask=(rr[:, None] < R) & (bb[None, :] < NB), other=0)
    dc = tl.sum(dc_blocks, 1).to(tl.int64)
    dp_blocks = tl.sum(tl.where(bb[None, :] < b, dc_blocks, 0), 1)
    pool = tl.sum(dc, 0)
    nn = tl.arange(0, NP)
    nr_blocks = tl.load(prefix_ptr + (2 * R + nn[:, None]) * NB + bb[None, :],
                        mask=(nn[:, None] < N) & (bb[None, :] < NB), other=0)
    nr = tl.sum(nr_blocks, 1).to(tl.int64)
    np_blocks = tl.sum(tl.where(bb[None, :] < b, nr_blocks, 0), 1)
    noff = tl.sum(tl.where(nn < m, nr, 0), 0)
    if b == 0:
        total = tl.sum(tl.where(nn == m, nr, 0), 0)
        tl.store(nrows_ptr + m, total)
        tl.store(vec_ptr + VEC_NROWS + m, total)
        tl.store(noff_ptr + m, noff)
    q = tl.load(npos_ptr + t.to(tl.int64) * N + m, mask=tm, other=-1)
    bits = tl.load(nbits_ptr + t.to(tl.int64) * N + m, mask=tm, other=0).to(tl.int32)
    staged = tm & (q >= 0)
    sp = tl.sum(tl.where(nn == m, np_blocks, 0), 0)
    pos = tl.where(staged, q + sp, -1)
    tl.store(npos_ptr + t.to(tl.int64) * N + m, pos, mask=tm)
    tl.store(stage_index_ptr + noff + pos.to(tl.int64), (pool + t).to(tl.int32), mask=staged)
    tl.store(stage_mask_ptr + noff + pos.to(tl.int64), bits.to(tl.int8), mask=staged)
    cd, cr = tl.maximum(pos, 0) // PER_D, tl.maximum(pos, 0) // PER_R
    bd, br = tl.arange(0, NBD), tl.arange(0, NBR)
    for g in tl.static_range(G):
        d = m * G + g
        p = tl.load(dpos_ptr + t.to(tl.int64) * R + d, mask=tm, other=-1)
        selected = tm & (p >= 0)
        dp = tl.sum(tl.where(rr == d, dp_blocks, 0), 0)
        global_p = tl.where(selected, p + dp, -1)
        tl.store(dpos_ptr + t.to(tl.int64) * R + d, global_p, mask=tm)
        doff = tl.sum(tl.where(rr < d, dc, 0), 0)
        if b == 0:
            tl.store(dcount_ptr + d, tl.sum(tl.where(rr == d, dc, 0), 0))
            send_blocks = tl.load(prefix_ptr + (R + d) * NB + bb, mask=bb < NB, other=0)
            tl.store(vec_ptr + d, tl.sum(send_blocks, 0).to(tl.int64))
            tl.store(doff_ptr + d, doff)
        tl.store(row_tok_ptr + doff + global_p.to(tl.int64), t.to(tl.int32), mask=selected)
        tl.store(row_dst_ptr + doff + global_p.to(tl.int64), tl.zeros([BLOCK], tl.int32) + d, mask=selected)
        hit = staged & (((bits >> g) & 1) != 0)
        hd = tl.histogram(tl.where(hit, cd * G + g, C * G), NBD)
        hr = tl.histogram(tl.where(hit, cr * G + g, CR * G), NBR)
        tl.atomic_add(vec_ptr + VEC_CUT_D + m * C * G + bd, hd.to(tl.int64), mask=(bd < C * G) & (hd > 0))
        tl.atomic_add(vec_ptr + VEC_CUT_R + m * CR * G + br, hr.to(tl.int64), mask=(br < CR * G) & (hr > 0))


@triton.jit
def _pack_rows_abs_kernel(x_ptr, xs_ptr, ids_ptr, w_ptr, row_tok_ptr, o32_ptr, o64_ptr, of_ptr, xs_stride_t, xs_stride_g,
                          DIRECT, X_WORDS: tl.constexpr, S_WORDS: tl.constexpr, S_OFF: tl.constexpr, SP: tl.constexpr,
                          I_OFF64: tl.constexpr, W_OFF32: tl.constexpr, ROW32: tl.constexpr, ROW64: tl.constexpr,
                          K: tl.constexpr, KP: tl.constexpr, BLOCK: tl.constexpr):
    """Send row r <- token row_tok[r] for the direct rows (r < DIRECT) and token r - DIRECT for the pool (one
    launch over both): hidden words, scales, the k ABSOLUTE ids (masked slots stay -1) and the k weights (0 on
    a masked slot)."""
    r = tl.program_id(0).to(tl.int64)
    if r < DIRECT:
        t = tl.load(row_tok_ptr + r).to(tl.int64)
    else:
        t = r - DIRECT
    o = r
    for c in tl.static_range(0, X_WORDS, BLOCK):
        offs = c + tl.arange(0, BLOCK)
        m = offs < X_WORDS
        xv = tl.load(x_ptr + t * X_WORDS + offs, mask=m, other=0)
        tl.store(o32_ptr + o * ROW32 + offs, xv, mask=m)
    if S_WORDS > 0:
        so = tl.arange(0, SP)
        sm = so < S_WORDS
        sv = tl.load(xs_ptr + t * xs_stride_t + so * xs_stride_g, mask=sm, other=0)
        tl.store(o32_ptr + o * ROW32 + S_OFF + so, sv, mask=sm)
    ks = tl.arange(0, KP)
    km = ks < K
    ids = tl.load(ids_ptr + t * K + ks, mask=km, other=-1).to(tl.int64)
    w = tl.load(w_ptr + t * K + ks, mask=km, other=0.0)
    tl.store(o64_ptr + o * ROW64 + I_OFF64 + ks, ids, mask=km)
    tl.store(of_ptr + o * ROW32 + W_OFF32 + ks, tl.where(ids >= 0, w, 0.0), mask=km)


@triton.jit
def _dedup_local_kernel(p64_ptr, p32_ptr, ids_out_ptr, w_out_ptr, ROWS, LO, NLOC,
                        I_OFF64: tl.constexpr, W_OFF32: tl.constexpr, ROW64: tl.constexpr, ROW32: tl.constexpr,
                        K: tl.constexpr, KP: tl.constexpr, BLOCK: tl.constexpr):
    """One program per BLOCK received rows: the row's k absolute ids -> my local expert index (-1 elsewhere) and its
    weights masked to them (DeepEP's wire convention), as contiguous [rows, K] outputs (one launch instead of two
    contiguous copies and four elementwise ops after every fan-out)."""
    pid = tl.program_id(0)
    rows = pid * BLOCK + tl.arange(0, BLOCK)
    rm = rows < ROWS
    ks = tl.arange(0, KP)
    m2 = rm[:, None] & (ks < K)[None, :]
    r64 = rows.to(tl.int64)[:, None]
    ids = tl.load(p64_ptr + r64 * ROW64 + I_OFF64 + ks[None, :], mask=m2, other=-1)
    w = tl.load(p32_ptr + r64 * ROW32 + W_OFF32 + ks[None, :], mask=m2, other=0.0)
    local = (ids >= LO) & (ids < LO + NLOC)
    tl.store(ids_out_ptr + r64 * K + ks[None, :], tl.where(local, ids - LO, -1), mask=m2)
    tl.store(w_out_ptr + r64 * K + ks[None, :], tl.where(local, w, 0.0), mask=m2)


@triton.jit
def _combine_dedup_kernel(recv_ptr, stgt_ptr, dpos_ptr, dbase_ptr, npos_ptr, rbase_ptr, out_ptr, R, PER_CHUNK,
                          CHUNK_ELEMS, ROW_ELEMS, H: tl.constexpr, N: tl.constexpr, K: tl.constexpr, BLOCK: tl.constexpr):
    """out[t] = the sum over the token's direct slots (rank d = stgt[t, k] >= 0: the row at dbase[d] + dpos[t, d] *
    ROW_ELEMS) and over the nodes with npos[t, m] >= 0 (the reduced row at rbase[m] + (p // PER_CHUNK) * CHUNK_ELEMS
    + (p % PER_CHUNK) * ROW_ELEMS); offsets in elements of the receive buffer, fp32 accumulation."""
    t = tl.program_id(0).to(tl.int64)
    for ch in tl.static_range(0, H, BLOCK):
        offs = ch + tl.arange(0, BLOCK)
        m = offs < H
        acc = tl.zeros([BLOCK], dtype=tl.float32)
        for j in tl.static_range(K):
            d = tl.load(stgt_ptr + t * K + j)
            ds = tl.maximum(d, 0).to(tl.int64)
            p = tl.load(dpos_ptr + t * R + ds).to(tl.int64)
            row = tl.load(dbase_ptr + ds) + tl.maximum(p, 0) * ROW_ELEMS
            # the masks compare per lane: Triton 3.9's interpreter refuses a mask from a scalar comparison (3.7 took it)
            v = tl.load(recv_ptr + row + offs, mask=m & (tl.zeros([BLOCK], dtype=tl.int64) + d >= 0), other=0.0)
            acc += v.to(tl.float32)
        for node in tl.static_range(N):
            p = tl.load(npos_ptr + t * N + node).to(tl.int64)
            pc = tl.maximum(p, 0)
            row = tl.load(rbase_ptr + node) + (pc // PER_CHUNK) * CHUNK_ELEMS + (pc % PER_CHUNK) * ROW_ELEMS
            v = tl.load(recv_ptr + row + offs, mask=m & (tl.zeros([BLOCK], dtype=tl.int64) + p >= 0), other=0.0)
            acc += v.to(tl.float32)
        tl.store(out_ptr + t * H + offs, acc.to(out_ptr.dtype.element_ty), mask=m)


class DedupCore(RowLayout):
    """The device plan under the row rule, the pack, the tables from the gathered counts, the collectives' layouts
    and descriptors, the receiver's id conversion, the compact masks and the per-token sum of the combine.
    local_size: GPUs per node (node-major ranks); max_tokens: the most tokens a rank dispatches in one call (the
    chunk tables' capacity, the same on every rank)."""

    BLOCK_X = 2048          # int32 words per chunk of the hidden row
    BLOCK_H = 1024          # elements per chunk of the combine reduction
    PLAN_BLOCK = 256        # tokens per program of the two plan kernels
    BLOCK_L = 64            # received rows per program of the local-id kernel

    def __init__(self, rank: int, world: int, num_local_experts: int, hidden_size: int, topk: int,
                 x_itemsize: int, scale_itemsize: int, scale_cols: int, expert_alignment: int = 1, *,
                 local_size: int, max_tokens: int):
        super().__init__(rank, world, num_local_experts, hidden_size, topk, x_itemsize, scale_itemsize,
                         scale_cols, expert_alignment)
        if world % local_size:
            raise ValueError(f"world {world} is not a multiple of the node size {local_size}")
        self.G, self.N = local_size, world // local_size
        self.mynode, self.myl = rank // local_size, rank % local_size
        self.combine_row_bytes = hidden_size * 2          # the bf16 expert output
        self.per_chunk_d = nd.rows_per_chunk(self.row_bytes, nd.FANOUT)
        self.per_chunk_r = nd.rows_per_chunk(self.combine_row_bytes, nd.REDUCE)
        self.max_tokens = int(max_tokens)
        self.C = nd.chunk_capacity(self.max_tokens, self.per_chunk_d)
        self.Cr = nd.chunk_capacity(self.max_tokens, self.per_chunk_r)
        self._bases_staging = None      # [pinned host, device, event] for the combine's bases

    def vec_length(self) -> int:
        return self.world + self.num_experts + self.N + self.N * self.C * self.G + self.N * self.Cr * self.G

    # ---- plan (device, no host wait) -------------------------------------------------------------
    def plan(self, topk_ids: torch.Tensor) -> DedupPlan:
        """Two launches into zeroed counts; the count vector is written in place."""
        T, K = topk_ids.shape
        R, G, N, E, C, Cr = self.world, self.G, self.N, self.num_experts, self.C, self.Cr
        dev = topk_ids.device
        if T > self.max_tokens:
            raise ValueError(f"{T} tokens exceed max_tokens {self.max_tokens} (the chunk tables' capacity)")
        ids32 = topk_ids if topk_ids.dtype == torch.int32 and topk_ids.is_contiguous() else \
            topk_ids.to(torch.int32).contiguous()
        a, b = R + E, R + E + N
        c0 = b + N * C * G
        vec = torch.zeros(self.vec_length(), dtype=torch.int64, device=dev)
        small = (torch.empty if T else torch.zeros)(2 * R + 2 * N, dtype=torch.int64, device=dev)
        dcount, doff, nrows, noff = small[:R], small[R:2 * R], small[2 * R:2 * R + N], small[2 * R + N:]
        dpos = torch.empty(T, R, dtype=torch.int32, device=dev)
        npos = torch.empty(T, N, dtype=torch.int32, device=dev)
        nbits = torch.empty(T, N, dtype=torch.int8, device=dev)
        cap = T * min(K, R)
        row_tok = torch.empty(cap + 1, dtype=torch.int32, device=dev)
        row_dst = torch.empty(cap + 1, dtype=torch.int32, device=dev)
        stage_index = torch.empty(T * N + 1, dtype=torch.int32, device=dev)
        stage_mask = torch.empty(T * N + 1, dtype=torch.uint8, device=dev)
        stgt = torch.empty(T, K, dtype=torch.int32, device=dev)
        if T:
            nb = triton.cdiv(T, self.PLAN_BLOCK)
            scratch = torch.empty((2 * R + N, nb), dtype=torch.int32, device=dev)
            _dedup_block_membership[(nb, N)](
                ids32, dpos, npos, nbits, scratch, stgt, vec[R:a], T, R, self.num_local_experts, self.mynode,
                self.myl, E, G=G, N=N, K=K, KP=self.kp, EP=max(2, triton.next_power_of_2(E + 1)),
                NB=nb, BLOCK=self.PLAN_BLOCK, num_warps=4)
            _dedup_block_maps[(nb, N)](
                dpos, npos, nbits, scratch, dcount, nrows, doff, noff,
                row_tok, row_dst, stage_index, stage_mask.view(torch.int8), vec,
                T, R, self.per_chunk_d, self.per_chunk_r, a, b, c0,
                G=G, N=N, C=C, CR=Cr, NB=nb, BP=max(2, triton.next_power_of_2(nb)),
                RP=max(2, triton.next_power_of_2(R)), NP=max(2, triton.next_power_of_2(N)),
                NBD=max(2, triton.next_power_of_2(C * G + 1)), NBR=max(2, triton.next_power_of_2(Cr * G + 1)),
                BLOCK=self.PLAN_BLOCK, num_warps=4)
        return DedupPlan(dpos, dcount, doff, npos, nrows, nbits, stage_index, stage_mask, row_tok, row_dst, stgt,
                         vec[:R], vec[R:a], vec[b:c0].view(N, C, G), vec[c0:].view(N, Cr, G), vec)

    # ---- the gathered counts ----------------------------------------------------------------------
    def tables(self, table: np.ndarray):
        """The gathered [R, vec_length] host table -> (nimble.dedup.Tables with both cuts, experts [R, E])."""
        R, E, N, G, C, Cr = self.world, self.num_experts, self.N, self.G, self.C, self.Cr
        if table.shape != (R, self.vec_length()):
            raise ValueError(f"gathered table {table.shape}, expected {(R, self.vec_length())}")
        a = R + E
        b = a + N
        c0 = b + N * C * G
        tables = nd.Tables(R, G, C, np.ascontiguousarray(table[:, :R]).astype(np.uint64),
                           np.ascontiguousarray(table[:, a:b]).astype(np.uint64),
                           table[:, b:c0].reshape(R, N, C, G).astype(np.uint32), Cr,
                           table[:, c0:].reshape(R, N, Cr, G).astype(np.uint32))
        return tables, np.ascontiguousarray(table[:, R:a])

    def check_tables(self, tables: "nd.Tables", T: int) -> None:
        """The gathered tables, before any buffer is sized from them: nothing negative, this rank's staged rows within
        its tokens times the nodes, and the row rule's two constraints (the library refuses them too). The host
        table alone: reading the plan back would cost two stream synchronizations per layer."""
        rows = tables.matrix_rows.astype(np.int64)
        node_rows = tables.node_rows.astype(np.int64)
        problem = None
        if (rows < 0).any() or (node_rows < 0).any() or node_rows[self.rank].sum() > T * self.N:
            problem = "negative or excess rows"
        else:
            try:
                tables.check_row_rule()
            except ValueError as exc:
                problem = str(exc)
        if problem is not None:
            raise RuntimeError(f"inconsistent dedup tables on rank {self.rank} (T={T}): {problem}; rows per source "
                               f"{rows.sum(1).tolist()}, staged rows per source {node_rows.sum(1).tolist()}")

    def direct_total(self, tables: "nd.Tables") -> int:
        """This rank's direct rows (the pack's direct blocks, ahead of the pool)."""
        return int(tables.direct_rows()[self.rank].sum())

    def local_counts(self, experts: np.ndarray) -> list[int]:
        """Rows per local expert, aligned, from the gathered [R, E] expert table."""
        lo = self.rank * self.num_local_experts
        return self.aligned(experts[:, lo:lo + self.num_local_experts].sum(0))

    # ---- dispatch --------------------------------------------------------------------------------
    def pack(self, x_q: torch.Tensor, x_s: Optional[torch.Tensor], topk_ids: torch.Tensor,
             topk_weights: torch.Tensor, plan: DedupPlan, direct_total: int) -> torch.Tensor:
        """The send buffer: the direct blocks (rows 0 .. direct_total, by the plan's row maps) then the pool (one
        row per token); one launch, absolute ids and every weight in every row."""
        T = topk_ids.shape[0]
        send = torch.empty(direct_total + T, self.row_bytes, dtype=torch.uint8, device=topk_ids.device)
        if T == 0:
            return send
        x32 = x_q.contiguous().view(torch.uint8).view(T, -1).view(torch.int32)
        xs32, st, sg = scale_words(x_s if self.s_words else None, x32)
        _pack_rows_abs_kernel[(direct_total + T,)](
            x32, xs32, topk_ids.to(torch.int32).contiguous(), topk_weights.to(torch.float32).contiguous(),
            plan.row_tok, send.view(torch.int32), send.view(torch.int64), send.view(torch.float32), st, sg,
            direct_total, X_WORDS=self.x_words, S_WORDS=self.s_words, S_OFF=self.off_s // 4, SP=self.sp,
            I_OFF64=self.off_i // 8, W_OFF32=self.off_w // 4, ROW32=self.row_bytes // 4, ROW64=self.row_bytes // 8,
            K=self.topk, KP=self.kp, BLOCK=self.BLOCK_X, num_warps=4)
        return send

    def fanout_geometry(self, tables: "nd.Tables"):
        """(region 0 bytes, region 1 bytes, the byte matrix) of this rank's fan-out receive buffer."""
        lay = tables.fanout_layout(self.rank, self.row_bytes, self.per_chunk_d)
        return lay.region0, lay.region1, tables.matrix_bytes(self.row_bytes)

    def fanout_call(self, tables: "nd.Tables", send_rows: int, plan: DedupPlan) -> "nd.DedupCall":
        return nd.DedupCall(nd.FANOUT, self.row_bytes, tables, send_rows=send_rows,
                            stage_index_ptr=plan.stage_index.data_ptr(), stage_mask_ptr=plan.stage_mask.data_ptr())

    def receive(self, recv: torch.Tensor, region0: int, x_dtype: torch.dtype, s_dtype: Optional[torch.dtype]):
        """The expert rows of region 0: strided views of hidden and scales, the ids converted to local experts (-1
        elsewhere) with the weights masked to them -- one launch."""
        rows = region0 // self.row_bytes
        packed = recv[:region0].view(rows, self.row_bytes)
        hidden = packed[:, self.off_x:self.off_x + self.x_bytes].view(x_dtype)
        scales = packed[:, self.off_s:self.off_s + self.s_bytes].view(s_dtype) if self.s_bytes else None
        ids = torch.empty(rows, self.topk, dtype=torch.int64, device=recv.device)
        weights = torch.empty(rows, self.topk, dtype=torch.float32, device=recv.device)
        if rows:
            flat = recv[:region0]
            _dedup_local_kernel[(triton.cdiv(rows, self.BLOCK_L),)](
                flat.view(torch.int64), flat.view(torch.float32), ids, weights, rows,
                self.rank * self.num_local_experts, self.num_local_experts,
                I_OFF64=self.off_i // 8, W_OFF32=self.off_w // 4, ROW64=self.row_bytes // 8,
                ROW32=self.row_bytes // 4, K=self.topk, KP=self.kp, BLOCK=self.BLOCK_L, num_warps=4)
        return hidden, scales, ids, weights

    def mask_snapshot(self, recv: torch.Tensor, tables: "nd.Tables") -> torch.Tensor:
        """The mask headers of the stage-1 streams this rank relays, copied from the fan-out's receive buffer into
        a buffer of the same layout in 16-byte rows (the full virtual extent is allocated, so the library's buffer
        validation holds; only mask bytes are written). The reduce reads its masks from here."""
        R, G = self.world, self.G
        per_src = self.per_chunk_d
        per = nd.rows_per_chunk(MASK_ROW_BYTES, nd.FANOUT)
        src = tables.fanout_layout(self.rank, self.row_bytes, per_src)
        dst = tables.fanout_layout(self.rank, MASK_ROW_BYTES, per)
        counts = tables.node_rows[:, self.mynode].astype(np.int64)
        sources = np.arange(R)
        counts[(sources % G != self.myl) | (sources // G == self.mynode)] = 0      # only the streams I relay
        compact = torch.empty(max(dst.region0 + dst.region1, 1), dtype=torch.uint8, device=recv.device)
        most = int(counts.max(initial=0))
        if most:
            geometry = np.concatenate([src.landing_base, dst.landing_base, counts]).astype(np.int64)
            if recv.device.type == "cuda":
                # pinned source: PyTorch's host allocator keeps it until the copy's event completes
                host = torch.empty(geometry.size, dtype=torch.int64, pin_memory=True)
                host.copy_(torch.from_numpy(geometry))
                device_geometry = host.to(recv.device, non_blocking=True)
            else:                                    # the Triton interpreter
                device_geometry = torch.from_numpy(geometry)
            _dedup_mask_snapshot[(R, triton.cdiv(most, 256))](
                recv, compact, device_geometry, per_src, per, R=R, BLOCK=256, CHUNK=CHUNK_BYTES, num_warps=4)
        return compact

    # ---- combine ---------------------------------------------------------------------------------
    def reduce_geometry(self, tables: "nd.Tables"):
        """(region 0 bytes, region 1 bytes, the layout, the byte matrix, the tables in the combine's cut)."""
        tr = tables.for_reduce()
        lay = tr.reduce_layout(self.rank, self.combine_row_bytes, self.per_chunk_r)
        return lay.region0, lay.region1, lay, tr.matrix_bytes(self.combine_row_bytes), tr

    def reduce_call(self, tables_r: "nd.Tables", masks: torch.Tensor) -> "nd.DedupCall":
        return nd.DedupCall(nd.REDUCE, self.combine_row_bytes, tables_r, dispatch_row_bytes=MASK_ROW_BYTES,
                            dispatch_landing_ptr=masks.data_ptr())

    def _combine_bases(self, layout: "nd.ReduceLayout", device: torch.device):
        """The combine's bases (bf16 elements) on the device WITHOUT a host wait: a pageable copy would wait for
        everything queued on the stream, the reduce included. A pinned staging buffer per core is filled on the
        host and copied on the current stream; the previous copy's event is awaited before the buffer is rewritten
        (one combine per layer per forward: a no-op in practice). The Triton interpreter takes plain tensors."""
        R, N = self.world, self.N
        if device.type != "cuda":
            return (torch.as_tensor((layout.direct_return_base // 2).astype(np.int64), device=device),
                    torch.as_tensor((layout.return_base // 2).astype(np.int64), device=device))
        st = self._bases_staging
        if st is None or st[1].device != device:
            st = self._bases_staging = [torch.empty(R + N, dtype=torch.int64).pin_memory(),
                                        torch.empty(R + N, dtype=torch.int64, device=device), None]
        pinned, dev, event = st
        if event is not None:
            event.synchronize()
        host = pinned.numpy()
        host[:R] = layout.direct_return_base // 2
        host[R:] = layout.return_base // 2
        stream = torch.cuda.current_stream(device)
        dev.copy_(pinned, non_blocking=True)
        st[2] = torch.cuda.Event()
        st[2].record(stream)
        return dev[:R], dev[R:]

    def combine(self, recv_r: torch.Tensor, plan: DedupPlan, layout: "nd.ReduceLayout", T: int,
                out_dtype: torch.dtype) -> torch.Tensor:
        """The per-token sum of its direct rows and its node partials (one launch)."""
        H = self.hidden_size
        out = torch.empty(T, H, dtype=out_dtype, device=recv_r.device)
        if T == 0:
            return out
        if layout.region0 + layout.region1 == 0:    # nothing comes back: every slot of these tokens is masked
            return out.zero_()
        dbase, rbase = self._combine_bases(layout, recv_r.device)
        _combine_dedup_kernel[(T,)](recv_r.view(torch.bfloat16), plan.slot_tgt, plan.direct_pos, dbase,
                                    plan.node_pos, rbase, out, self.world, self.per_chunk_r, CHUNK_BYTES // 2,
                                    self.combine_row_bytes // 2, H=H, N=self.N, K=self.topk, BLOCK=self.BLOCK_H,
                                    num_warps=4)
        return out
