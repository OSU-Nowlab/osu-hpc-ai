"""The expert-parallel dispatcher: DeepEP-normal dispatch and combine over an AllToAllV.

    import nimble
    from nimble.moe import Dispatcher

    comm = nimble.init(group=ep_group, set_default=False)
    dispatcher = Dispatcher(ep_group, comm=comm, num_experts=256, hidden_size=7168, topk=8,
                            x_dtype=torch.float8_e4m3fn, scale_dtype=torch.int32, scale_cols=14,
                            expert_alignment=128)
    out = dispatcher.dispatch(x_q, x_scales, topk_ids, topk_weights)
    # the experts run on out.hidden, out.scales, out.topk_ids, out.topk_weights, out.expert_counts
    y = dispatcher.combine(expert_rows, out.handle)

dispatch and combine are collectives over `group`: every rank calls them in the same order. A call plans on the
device, exchanges one count vector (the call's one host wait: the table sizes every buffer), packs, transfers and
returns DeepEP-normal output: each received row carries the token's hidden state and scales once per destination
rank, its top-k ids as local expert indices (-1 for the experts that live elsewhere) and its weights (0 there), and
the per-local-expert row counts rounded up to expert_alignment. combine takes, per received row, the expert output
already weighted and summed over the row's local experts, and returns each token's sum over its ranks, in fp32
rounded once to the input dtype.

Modes (`mode`):
  fused  one AllToAllV per direction: transport "nimble" (nimble.alltoallv on `comm`) or "torch"
         (torch.distributed.all_to_all_single on `group`; NCCL on an NCCL group -- the baseline that differs from
         NIMBLE's only in the transport).
  dedup  the MoE two-hop inside one NIMBLE call per direction (NIMBLE_MATRIX_FLAG_DEDUP): a token bound for several
         ranks of a remote node crosses the network once, to the rail-aligned relay there, which fans it out over
         NVLink and reduces the node's expert outputs before they cross back. Needs transport "nimble", two or
         more nodes and a communicator created with NIMBLE_DEDUP=1 in the environment; `max_tokens` bounds the
         tokens per call.
"""
from __future__ import annotations

from typing import NamedTuple, Optional

import numpy as np
import torch
import torch.distributed as dist

from .. import dedup as nd
from .._comm import Communicator
from .._torch import alltoallv
from .dedup import DedupCore, DedupPlan
from .fused import FusedCore


class Dispatched(NamedTuple):
    hidden: torch.Tensor                  # [rows, H] x_dtype, a strided view of the receive buffer
    scales: Optional[torch.Tensor]        # [rows, scale_cols] scale_dtype, a strided view; None without scales
    topk_ids: torch.Tensor                # [rows, K] int64: the local expert index, -1 where the expert lives elsewhere
    topk_weights: torch.Tensor            # [rows, K] fp32, 0 where topk_ids is -1
    expert_counts: list                   # rows per local expert, rounded up to expert_alignment
    handle: object                        # for combine


class _FusedHandle(NamedTuple):
    slot_row: torch.Tensor                # [T, K] the send row of each top-k slot (-1: none)
    tokens: int
    rows: np.ndarray                      # [R, R] rows source s sent to rank d


class _DedupHandle(NamedTuple):
    plan: DedupPlan
    tables: nd.Tables
    masks: torch.Tensor                   # the compact mask headers the reduce reads
    tokens: int


class Dispatcher:
    """DeepEP-normal dispatch and combine for one expert-parallel group (see the module docstring).

    group: the torch.distributed group of the expert-parallel ranks (global expert e lives on group rank
    e // (num_experts / world)); comm: a NIMBLE communicator over the same ranks in the same order (transport
    "nimble"); x_dtype: the dispatched hidden dtype (FP8 or BF16); scale_dtype / scale_cols: the per-token scale
    row as the quantizer stores it (e.g. int32 x ceil(H / 512) for packed UE8M0, float32 x H / 128), None / 0
    without scales; expert_alignment: the per-expert counts are rounded up to it (DeepGEMM's contiguous layout:
    128)."""

    def __init__(self, group, *, num_experts: int, hidden_size: int, topk: int, x_dtype: torch.dtype,
                 scale_dtype: Optional[torch.dtype] = None, scale_cols: int = 0, expert_alignment: int = 1,
                 mode: str = "fused", transport: str = "nimble", comm: Optional[Communicator] = None,
                 max_tokens: int = 16384):
        if mode not in ("fused", "dedup"):
            raise ValueError(f"mode {mode!r}: fused or dedup")
        if transport not in ("nimble", "torch"):
            raise ValueError(f"transport {transport!r}: nimble or torch")
        if mode == "dedup" and transport != "nimble":
            raise ValueError("the dedup mode is a NIMBLE collective: transport 'nimble'")
        if transport == "nimble" and comm is None:
            raise ValueError("transport 'nimble' needs comm (nimble.init(group=..., set_default=False))")
        if mode == "dedup" and comm.world_size == comm.local_world_size:
            raise ValueError("the dedup mode needs at least two nodes (it saves duplicate rows between nodes); "
                             "use mode 'fused' on one node")
        if (scale_dtype is None) != (scale_cols == 0):
            raise ValueError("scale_dtype and scale_cols go together")
        self.group, self.comm = group, comm
        self.rank, self.world = dist.get_rank(group), dist.get_world_size(group)
        if comm is not None and (comm.rank, comm.world_size) != (self.rank, self.world):
            raise ValueError(f"the communicator is rank {comm.rank} of {comm.world_size}, the group's rank "
                             f"{self.rank} of {self.world}")
        if num_experts % self.world:
            raise ValueError(f"{num_experts} experts do not divide over {self.world} ranks")
        self.mode, self.transport = mode, transport
        self.hidden_size, self.topk = hidden_size, topk
        self.x_dtype, self.scale_dtype, self.scale_cols = x_dtype, scale_dtype, scale_cols
        layout = (self.rank, self.world, num_experts // self.world, hidden_size, topk,
                  torch.empty((), dtype=x_dtype).element_size(),
                  torch.empty((), dtype=scale_dtype).element_size() if scale_dtype is not None else 0,
                  scale_cols, expert_alignment)
        if mode == "fused":
            self.core = FusedCore(*layout)
        else:
            self.core = DedupCore(*layout, local_size=comm.local_world_size, max_tokens=max_tokens)
            for row_bytes, kind, ours in ((self.core.row_bytes, nd.FANOUT, self.core.per_chunk_d),
                                          (self.core.combine_row_bytes, nd.REDUCE, self.core.per_chunk_r)):
                theirs = nd.rows_per_chunk(row_bytes, kind, comm._lib)
                if theirs != ours:
                    raise RuntimeError(f"the dedup chunk rule differs from the library's: {ours} vs {theirs} rows "
                                       f"of {row_bytes} bytes")

    # ---- dispatch ---------------------------------------------------------------------------------
    def dispatch(self, x: torch.Tensor, x_scales: Optional[torch.Tensor], topk_ids: torch.Tensor,
                 topk_weights: torch.Tensor) -> Dispatched:
        """x: [T, H] x_dtype; x_scales: [T, scale_cols] scale_dtype (any strides) or None; topk_ids: [T, K]
        integer global expert ids (-1: a masked slot); topk_weights: [T, K] float."""
        T = x.shape[0]
        if x.shape != (T, self.hidden_size) or x.dtype != self.x_dtype:
            raise ValueError(f"x {tuple(x.shape)} {x.dtype}, expected [T, {self.hidden_size}] {self.x_dtype}")
        got = None if x_scales is None else (tuple(x_scales.shape), x_scales.dtype)
        want = None if self.scale_dtype is None else ((T, self.scale_cols), self.scale_dtype)
        if got != want:
            raise ValueError(f"x_scales {got}, expected {want}")
        if topk_ids.shape != (T, self.topk) or topk_weights.shape != (T, self.topk):
            raise ValueError(f"topk_ids {tuple(topk_ids.shape)} / topk_weights {tuple(topk_weights.shape)}, "
                             f"expected [T, {self.topk}]")
        if self.mode == "dedup":
            return self._dispatch_dedup(x, x_scales, topk_ids, topk_weights)
        return self._dispatch_fused(x, x_scales, topk_ids, topk_weights)

    def _gather(self, vec: torch.Tensor) -> np.ndarray:
        """Every rank's count vector, as an [R, len] host table: the call's one host wait."""
        table = torch.empty(self.world * vec.numel(), dtype=torch.int64, device=vec.device)
        dist.all_gather_single(table, vec, group=self.group)
        return table.view(self.world, -1).cpu().numpy()

    def _dispatch_fused(self, x, x_scales, topk_ids, topk_weights) -> Dispatched:
        core = self.core
        T = x.shape[0]
        plan = core.plan(topk_ids)
        table = self._gather(plan.vec)
        core.check_table(table, T)
        rows = np.ascontiguousarray(table[:, :self.world])
        send = core.pack(x, x_scales, topk_ids, topk_weights, plan, int(rows[self.rank].sum()))
        recv = torch.empty(int(rows[:, self.rank].sum()), core.row_bytes, dtype=torch.uint8, device=x.device)
        self._alltoallv(recv, send, rows)
        hidden, scales, ids, weights = core.unpack(recv, self.x_dtype, self.scale_dtype)
        return Dispatched(hidden, scales, ids, weights, core.local_counts(table),
                          _FusedHandle(plan.slot_row, T, rows))

    def _dispatch_dedup(self, x, x_scales, topk_ids, topk_weights) -> Dispatched:
        core = self.core
        T = x.shape[0]
        plan = core.plan(topk_ids)
        tables, experts = core.tables(self._gather(plan.vec))
        core.check_tables(tables, T)
        region0, region1, matrix = core.fanout_geometry(tables)
        direct = core.direct_total(tables)
        send = core.pack(x, x_scales, topk_ids, topk_weights, plan, direct)
        recv = torch.empty(max(region0 + region1, 1), dtype=torch.uint8, device=x.device)
        self._dedup_call(send, recv, matrix, core.fanout_call(tables, direct + T, plan))
        hidden, scales, ids, weights = core.receive(recv, region0, self.x_dtype, self.scale_dtype)
        return Dispatched(hidden, scales, ids, weights, core.local_counts(experts),
                          _DedupHandle(plan, tables, core.mask_snapshot(recv, tables), T))

    # ---- combine ----------------------------------------------------------------------------------
    def combine(self, expert_rows: torch.Tensor, handle) -> torch.Tensor:
        """expert_rows: [rows, H], one per dispatched row (bf16 in the dedup mode). Returns [T, H]."""
        y = expert_rows.contiguous()
        if self.mode == "dedup":
            plan, tables, masks, T = handle
            self._check_rows(y, int(tables.matrix_rows[:, self.rank].sum()))
            if y.dtype != torch.bfloat16:
                raise ValueError(f"the dedup combine reduces bf16 rows, got {y.dtype}")
            r0, r1, layout, matrix, tables_r = self.core.reduce_geometry(tables)
            recv = torch.empty(max(r0 + r1, 1), dtype=torch.uint8, device=y.device)
            self._dedup_call(y, recv, matrix, self.core.reduce_call(tables_r, masks))
            return self.core.combine(recv, plan, layout, T, y.dtype)
        slot_row, T, rows = handle
        self._check_rows(y, int(rows[:, self.rank].sum()))
        back = torch.empty(int(rows[self.rank].sum()), y.shape[1], dtype=y.dtype, device=y.device)
        self._alltoallv(back, y, np.ascontiguousarray(rows.T))
        return self.core.combine(back, slot_row, T, y.dtype)

    def _check_rows(self, y: torch.Tensor, rows: int) -> None:
        if y.shape != (rows, self.hidden_size):
            raise ValueError(f"expert_rows {tuple(y.shape)}, expected [{rows}, {self.hidden_size}] (one per "
                             "dispatched row)")

    # ---- transport --------------------------------------------------------------------------------
    def _alltoallv(self, recv: torch.Tensor, send: torch.Tensor, rows: np.ndarray) -> None:
        """One AllToAllV of whole rows; rows[s, d] = the rows source s sends to rank d (the same on every rank)."""
        if not rows.any():
            return
        send_counts, recv_counts = rows[self.rank].tolist(), rows[:, self.rank].tolist()
        if self.transport == "nimble":
            alltoallv(recv, send, recv_counts, send_counts, matrix=rows, comm=self.comm)
        else:
            dist.all_to_all_single(recv, send, output_split_sizes=recv_counts, input_split_sizes=send_counts,
                                   group=self.group)

    def _dedup_call(self, send: torch.Tensor, recv: torch.Tensor, matrix: np.ndarray, call: nd.DedupCall) -> None:
        if not matrix.any():
            return
        self.comm.alltoallv_bytes(send.data_ptr() if send.numel() else 0, recv.data_ptr(), matrix,
                                  torch.cuda.current_stream(recv.device).cuda_stream, dedup=call)
