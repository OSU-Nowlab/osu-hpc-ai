"""NIMBLE's MoE backends for serving frameworks, built on nimble.moe.Dispatcher.

    sglang   NimbleEPDispatcher: SGLang's --moe-a2a-backend nimble and nccl_a2a
             (tools/sglang_ep/setup/sglang registers them in SGLang)
    vllm     NimbleAll2AllManager and NimblePrepareAndFinalize: vLLM's --all2all-backend nimble and nccl_a2a
             (tools/vllm_ep/setup/vllm registers them in vLLM 0.30.0)

Each module imports its framework: import it inside that framework only.
"""
