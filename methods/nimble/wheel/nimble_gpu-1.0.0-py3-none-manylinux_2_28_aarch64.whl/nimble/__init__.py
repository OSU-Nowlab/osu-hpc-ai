"""NIMBLE for Python and PyTorch.

    import torch, torch.distributed as dist
    import nimble

    dist.init_process_group("nccl")
    nimble.init()                                  # collective; device = LOCAL_RANK
    ...
    nimble.alltoallv(output, input, output_split_sizes, input_split_sizes,
                     matrix=rows_table, stream=stream)   # NIMBLE
    dist.all_to_all_single(output, input, output_split_sizes, input_split_sizes)  # NCCL
    ...
    nimble.destroy()

The package is a ctypes binding of the public C API (include/nimble/nimble.h)
over libnimble.so; it registers and pins nothing and keeps nothing between calls.
`nimble.dedup` holds the caller's side of the dedup flag (NIMBLE_MATRIX_FLAG_DEDUP);
`nimble.moe` (imported on its own: it needs Triton) the MoE dispatcher, and
`nimble.integrations` its SGLang and vLLM backends.
"""

from ._version import __version__
from ._capi import (ABI_VERSION, DEDUP_FANOUT, DEDUP_REDUCE, MATRIX_FLAG_DEDUP,
                    MATRIX_FLAG_HOST_BYTES, NimbleError, candidate_library_paths, library_path,
                    load_library, version, version_string)
from ._comm import Communicator
from . import dedup
from ._torch import (all_to_all_single, alltoallv, default_communicator, destroy, init,
                     row_bytes, row_from_splits, rows_matrix, validate_matrix)

__all__ = [
    "__version__", "ABI_VERSION", "MATRIX_FLAG_HOST_BYTES", "MATRIX_FLAG_DEDUP", "DEDUP_FANOUT", "DEDUP_REDUCE",
    "NimbleError", "Communicator", "dedup",
    "candidate_library_paths", "library_path", "load_library", "version", "version_string",
    "init", "destroy", "default_communicator", "alltoallv", "all_to_all_single",
    "rows_matrix", "row_from_splits", "validate_matrix", "row_bytes",
]
